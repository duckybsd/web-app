x=$(system_profiler SPUSBDataType -detailLevel  basic | sed '1,/SerialMode/ d'| sed '1,/Manufacturer/ d'|sed '1,1 s/Location ID: 0x//'|sed '2,$ d'|sed 's/00.*//'|sed 'y/abcdefghijklmnopqrstuvwxyz/ABCDEFGHIJKLMNOPQRSTUVWXYZ/' )
sleep 3
stty -f /dev/tty.usbmodem`echo $x`1 2400